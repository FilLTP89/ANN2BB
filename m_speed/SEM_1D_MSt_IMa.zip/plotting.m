%==========================================================================
%Figure 2: Snapshots of wave propagation at times t_check_dt
%==========================================================================

if pg2=='y'
tc=t_check_dt;
figure;
for kk=1:length(tc)
    tc(kk)=find(abs(t-tc(kk))<deltat,1);
end
    maxd=max(disp.history(:,tc(1)));
    mind=min(disp.history(:,tc(1)));
if abs(mind)>maxd
    ulimit=ceil(abs(mind)*100)/100;
    llimit=-ulimit;
else
    ulimit=ceil(maxd*100)/100;
    llimit=-ulimit;
end
for kk=1:length(tc)
    label=['t=',num2str(t_check_dt(kk))];
 subplot(length(t_check_dt),1,kk);
    plot(xq,disp.history(:,tc(kk)));ylim([llimit ulimit]);grid on;...
        title(label);hold on
end
xlabel('Distance (m)');
end

%==========================================================================
%Figure 3: Wave Propagation Animation
%==========================================================================
if pg3=='y'
h=figure;
 maxd=max(max(disp.history));
    mind=min(min(disp.history));
if abs(mind)>maxd
    ulimit=ceil(abs(mind)*100)/100;
    llimit=-ulimit;
else
    ulimit=ceil(maxd*100)/100;
    llimit=-ulimit;
end
for kk=1:cycles
    z=kk*deltat;
    subplot(2,1,1);
       plot(xq,disp.history(:,kk));ylim([llimit ulimit]);xlabel('Position on Soil Layer');...
           ylabel('Displacement');
    subplot(2,1,2);
       plot(t(kk),surf_disp(kk));grid on;hold on;xlim([0 max(t)]);ylim([llimit ulimit]);...
           xlabel('Time (sec)');ylabel('Surface Displacement')
       F(kk)=getframe(h);
end
% h2=figure
% figure;movie(h2,F,2)
end
