function LL=Lagrange(ksi)

%Calculation of the coefficients of the Lagrance polynomials
s=length(ksi);
LL=zeros(s);
for k=1:s
    r=[ksi(1:k-1) ksi(k+1:s)]; %ommit for each k the k-th root, i.e. \ksi_k
    p=poly(r);                 %coefficients of the polynomial, whose roots are represented by r (nominator of the formula of the Lagrance polynomial \psi_k)
    A=polyval(p,ksi(k));       %value of the polynomial on \ksi_k (denominator of the formula of the Lagrance polynomial \psi_k)
    LL(k,:)=p/A;               %matrix of the coefficient of the Lagrance polynomial \psi_k
end
