function [ksi, weights]=gauss_lobatto(N,k)

%Calculation of the nodes and the weights w.r.t the Gauss-Lobatto quadrature
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Starting values of the coefficient matrix L for the Legendre polynomials
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
L=zeros(N+1,N+1); %lines=polynomials L0, L1,...Ln; columns=coefficients w.r.t. the vector x=[x^N ... x^0]'
dL=zeros(N+1,N);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Use of the recursive formula
%\[L_{n+1}(x)=\frac{2n+1}{n+1}x\,L_n(x)-\frac{n}{n+1}L_{n-1}(x)\;,\;n\geq1\;,\]  %(LaTeX Format)
%where $L_0(x)=1$ and $L_1(x)=x$.
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%NOTE THAT THE POLYNOMIAL L_{n+1} CORRESPONDS TO THE LINE n+2 OF THE COEFFICIENT MATRIX L
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
L(1,N+1)=1; %coefficient of x^0 corresponding to the L_0 polynomial
L(2,N)=1; %coeffiecient of x^1 corresponding to the L_1 polynomial
for ii=1:k
    a=(2*ii+1)/(ii+1);
    b=ii/(ii+1);
    L1=[L(ii+1,2:N+1).*a 0];
    L(ii+2,:)=L1-L(ii,:).*b;
end

Ln=L(N+1,:)  ;  %coefficients of the polynomial of order N
dLn=polyder(Ln);%coefficients of the derivative (L'_n) of the polynomial L_n
r = roots(conv([-1 0 1],dLn)); %roots of the polynomial (1-x^2)L'_n <---> coordinates of the internal GL nodes
ksi=sort(r)';      %sorts the coordinates of the GL nodes in ascending order.
ksi=[-1 ksi(2:N) 1];   %eliminates rounding errors in the extreme values

for i=1:length(ksi)
    Lp(i)=(polyval(Ln,ksi(i)))^2;
    weights(i)=(2/(N*(N+1)))*(1/Lp(i)); %weights for the LGL quadrature
    y=0;
end

