function [GMTS] = beta_method(uimp,vimp,aimp,...
                              cicli,...
                              deltat,...
                              m,k,c,...
                              N,...
                              xq,...
                              n_el,rho_el,G_el,...
                              phiq,dphiq,...
                              ngl,weights,ndof,...
                              nodelem,...
                              nodes_list,...
                              Ja)

%Newmark's beta method in its incremental formulation 
%expanding to the mdof case and to allow beta=0 the algorithm proposed by
%Chopra A., Dynamic of Structures,Sec. 5.4.3. 

%The final output is mxn matrices of displacement (d), velocity (v) and 
%acceleration (a), where m is the number of unconstrained
%dof's and n the number of time steps. Thus, e.g. d(i,j) is the
%displacement of the ith unconstrained node at the jth time step.

%The equation to be solved is the one taking into account
%the imposed displacements as support excitation. That is,
%m_f*a_f+c_f*v_f+k_f*d_f=f,
%where
%f=-m_c*a_c-c_c*v_c-k_c*d_c,
%and the subscripts f and c refer to unconstrained and constrained dof's
%respectively. Reference, Chopra A., Sec. 9.7

beta=0;
gamma=0.5;
ndof=size(m,1);

%% NLE
strain = [0.0001	0.0003	0.001	0.003	0.01	0.03	0.1	    0.3     1	    3	    10].*0.01;
GG0 =    [1	        1	    1	    0.981	0.941	0.847	0.656	0.438	0.238	0.144	0.11];
       


%% Static allocation of the vectors:
dfhat = zeros(ndof-1,cicli);
dfi = zeros(ndof-1,cicli);

d = zeros(ndof-1,cicli);
v = zeros(ndof-1,cicli);
a = zeros(ndof-1,cicli);

dxq = xq(2:ndof)-xq(1:ndof-1);
epsilon_xy = zeros(ndof-1,cicli);
sigma_xy = zeros(ndof-1,cicli);

G_dof = repmat(G_el,N,1);
G_dof = reshape(G_dof,ndof-1,1);



dd = zeros(ndof-1,cicli-1);
dv = zeros(ndof-1,cicli-1);
da = zeros(ndof-1,cicli-1);


%Preparation of the involved matrices
mf=m(2:end,2:end);  %portion of the matrices
kf=k(2:end,2:end);  %corresponding to unconstrained dof
cf=c(2:end,2:end);  %
mc=m(2:end,1);      %portion corresponding
kc=k(2:end,1);      %to the constrained dof
cc=c(2:end,1);      %

% for z=1:cicli
% fi(:,z)=-mc*aimp(z)-cc*vimp(z)-kc*uimp(z);
% end

fi=-mc*aimp'-cc*vimp'-kc*uimp';
dfi=fi(:,2:end)-fi(:,1:end-1);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%initial values and evaluation of coefficients involved
d(1:ndof-1,1)=0;
v(1:ndof-1,1)=0;
a(:,1)=mf\(fi(:,1)-cf*v(:,1)-kf*d(:,1));
dt=deltat;


%% Beta Method
cost1 = (beta*dt/gamma);
cost2 = (1/2-beta/gamma)*dt^2;

cost3 = (1/(gamma*dt));
cost4 = (1/gamma);

chat = cf + cost3*mf + cost1*kf;
acoef = -dt*kf;
bcoef = cost4*mf - cost2*kf;



for z=1:cicli-1
    dfhat(:,z)=dfi(:,z)+acoef*v(:,z)+bcoef*a(:,z);
    
    dv(:,z)=chat\dfhat(:,z);
    
    dd(:,z)=cost1.*dv(:,z) + ...
            cost2.*a(:,z)+...
            dt.*v(:,z);
        
    da(:,z)= cost3.*dv(:,z) - ...
             cost4.*a(:,z);
         
    v(:,z+1)=dv(:,z)+v(:,z);
    d(:,z+1)=dd(:,z)+d(:,z);
    a(:,z+1)=da(:,z)+a(:,z);
    
    disp_all = [uimp(z); d(1:ndof-1,z)];
    [epsilonxy] = make_strain_tensor(disp_all, ...
                                     nodes_list, ...
                                     dphiq, Ja, ....
                                     ndof);
                                 
    %epsilon_xy(:,z) = epsilonxy(2:ndof);
    
    epsilon_xy(:,z) = ( disp_all(2:ndof)-disp_all(1:ndof-1) )./dxq;
    
    ID = max(find(abs(epsilon_xy(ndof-1,z)) >= strain));
    
    if isempty(ID)
        
    else
       %Mass & Stiffness Matrix
      
       %y = cost10*x + cost11;
       if ID <= 10
           cost10 = (GG0(ID+1)-GG0(ID))/(strain(ID+1)-strain(ID));
           cost11 = GG0(ID+1) - cost10*strain(ID+1);
           GG0_star = cost10*epsilon_xy(ndof-1,z) + cost11;
       else
           GG0_star = GG0(11);
       end
       
       G_el_NEW = G_el; 
       G_el_NEW(20) = G_el_NEW(20).*GG0_star;
       
       G_dof = repmat(G_el_NEW,N,1);
       G_dof = reshape(G_dof,ndof-1,1);
       
       [m, k] = mass_stiff(n_el,rho_el,G_el_NEW,...
                           phiq,dphiq,...
                           ngl,weights,ndof,...
                           nodelem,...
                           nodes_list,...
                           Ja); 
                       
       %Preparation of the involved matrices
        mf=m(2:end,2:end);  %portion of the matrices
        kf=k(2:end,2:end);  %corresponding to unconstrained dof
        cf=c(2:end,2:end);  %
        mc=m(2:end,1);      %portion corresponding
        kc=k(2:end,1);      %to the constrained dof
        cc=c(2:end,1);      %
      

        %% Beta Method
        cost1 = (beta*dt/gamma);
        cost2 = (1/2-beta/gamma)*dt^2;

        cost3 = (1/(gamma*dt));
        cost4 = (1/gamma);

        chat = cf + cost3*mf + cost1*kf;
        acoef = -dt*kf;
        bcoef = cost4*mf - cost2*kf;
    end
    
    
    sigma_xy(:,z) = epsilon_xy(:,z).*G_dof;
    
    clc
    t=z*dt
end

GMTS.acc = a;
GMTS.vel = v;
GMTS.dis = d;
GMTS.eps_xy = epsilon_xy;
GMTS.sig_xy = sigma_xy;






