function [ a v ] = num_dif(uimp,cycles,deltat)
%subroutine to evaluate the derivatives of a discrete imposed displacement
%throughout the time history
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%The algorithm uses the forward difference scheme for the first value of
%the vector of acceleration and velocity and the backward difference for
%the last value of the respective vectors. The values in between are
%calculated through the central difference algorithm

d=uimp;
n=cycles;
h=deltat;
for k=1:n
    if k==1
        v(k,1)=(d(k+1)-d(k))/h;
        a(k,1)=(d(k+2)-2*d(k+1)+d(k))/h^2;
    elseif k==n
        v(k,1)=(d(k)-d(k-1))/h;
        a(k,1)=(d(k)-2*d(k-1)+d(k-2))/h^2;
    else
    v(k,1)=(d(k+1)-d(k-1))/(2*h);
    a(k,1)=(d(k+1)-2*d(k)+d(k-1))/h^2;
    end
end


