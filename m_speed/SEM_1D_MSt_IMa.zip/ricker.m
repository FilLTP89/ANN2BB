function [spost]=ricker(x,t,c,amp,fmax,tzero)
fp=fmax/3;
b=pi^2*fp^2;
%Function of the input displacement at node 1 (x=0)
spost=amp*(1-2*b*((t-x/c)-tzero).^2).*exp(-b*((t-x/c)-tzero).^2);
% spost=spost';
