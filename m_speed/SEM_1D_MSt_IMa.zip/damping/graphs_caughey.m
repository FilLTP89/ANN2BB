nf=8;
cdr=0.05;
f1=0.1;
f2=5;

ai=caughey(cdr,f1,f2,nf);
% % nf=6;      %number of control frequencies
% % cdr=0.05;  %desired critical damping ration at the control frequencies
% % 
% % f1=0.5;  %lowest control frequency
% % f2=5;   %maximum control frequency
f=[f1:(f2-f1)/(nf-1):f2]';
% w=2*pi*f;
zeta=cdr*ones(nf,1);
% %evaluation of the coefficients a_i from the equation 
% %\zeta_i=0.5a_jw^{2j-1}
% 
% for j=1:nf
%     for k=1:nf
%         coeff(j,k)=0.5*w(j)^(2*(k-1)-1);
%     end
% end
% 
% ai=coeff\zeta;
% a=ai;
fs=[0.1:0.1:10]';
ws=2*pi*fs;
for k=1:length(fs)
    z(k,1)=0;
    for j=1:nf
        z(k,1)=z(k,1)+0.5*ai(j)*ws(k)^(2*(j-1)-1);
    end
end
figure
plot(fs,z);grid on;hold on
plot(fs,cdr*ones(length(fs),1),'k');
plot(f,zeta,'ko')
graph=[fs z];ylim([0,0.1])
print -depsc -tiff -r300 caughey
save caughey.damp -ascii -tabs graph
