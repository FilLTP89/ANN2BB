function [ai]=caughey(cdr,f1,f2,nf)

f=[f1:(f2-f1)/(nf-1):f2]';
w=2*pi*f;
zeta=cdr*ones(nf,1);
%evaluation of the coefficients a_i from the equation 
%\zeta_i=0.5a_jw^{2j-1}

for j=1:nf
    for k=1:nf
        coeff(j,k)=0.5*w(j)^(2*(k-1)-1);
    end
end

ai=coeff\zeta;
a=ai;




