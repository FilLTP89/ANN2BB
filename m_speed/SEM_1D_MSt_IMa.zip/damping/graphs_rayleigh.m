clear
clc
close
addpath ./../Programma_EN
cdr=0.05;
fi=1;
fj=5;

[a,b,am,bm]=rayleigh(cdr,fi,fj);

fn=[0.1:0.1:5];
wn=2*pi*fn';

z=0.5*(a./wn+b*wn);
zm=0.5*(am./wn+bm*wn);

zcontrol=cdr*ones(length(fn),1);
plot(fn,z,'k',fn,zm,'r');xlabel('Frequency f'); ylabel('Critical Damping Ratio');...
    legend('\zeta','\zeta_m');grid on;hold on
plot(fn,zcontrol);
plot([fi fj],[z(find(fn==fi)) z(find(fn==fj))],'ko');
plot([fi fj],[zm(find(fn==fi)) zm(find(fn==fj))],'ko');
mgraph=[fn' zm];
save rayleigh.damp -ascii -tabs mgraph
print -depsc -tiff -r300 rayleigh
