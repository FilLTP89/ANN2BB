function [a,b,am,bm]=rayleigh(cdr, fi, fj)

%Subroutine for the evaluation of the mass matrix (a) and stiffness matrix
%(b) coefficients, with respect to the Rayleigh expression for the damping
%matrix. The algorithm evaluates the coefficients in the case a critical 
%damping ratio (cdr) is assosiated to the frequencies fi and fj (variables a & b)
%and in the case that the prescribed cdr is desired to be the mean value of
%the damping ratio in the frequency interval [fi,fj]

wi=2*pi*fi;
wj=2*pi*fj;

a=cdr*2*wi*wj/(wi+wj);
b=cdr*2/(wi+wj);

cdrm=cdr*(wj-wi)/(log(wj/wi)*wi*wj/(wi+wj)+(wj^2-wi^2)/(2*wi+2*wj));
% cdrm=cdr/(log(wj/wi)*wi*wj/(wj^2-wi^2)+1/2);
am=cdrm*2*wi*wj/(wi+wj);
bm=cdrm*2/(wi+wj);
