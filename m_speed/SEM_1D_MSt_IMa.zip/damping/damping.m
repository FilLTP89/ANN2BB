function[c k]=damping(type,f,cdr,nf,k,m)
%Subroutine for the Calculation of the damping matrix. Damping introduced
%can be of the Raileigh, the Caughey or the Kosloff & Kosloff type.
fi=f(1);
fj=f(2);
if type==1
%Calculation of Rayleigh Damping 
[a,b,am,bm]=rayleigh(cdr,fi,fj);
c=am*m+bm*k;
k=k;
elseif type==2
%Calculation of Caughey Damping 
[ai]=caughey(cdr,fi,fj,nf);
factor=m\k;
for modes=1:nf
    c=c+ai(modes)*m*factor^(modes-1);
end
k=k;
elseif type==3
%Introduction of Kosloff & Kosloff damping
Q=1/(2*cdr);                       %Q-factor
fq=(fi+fj)/2;                      %Frequency corresponding to Q-factor
chi=pi*fq/Q;                       %Decay Factor
c=(2*chi)*m;
k=k+(chi^2)*m;                     %Imposed modification of the stifness matrix
else
    c=zeros(size(k));
    k=k;
end



