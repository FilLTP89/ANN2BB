function VP=Lagrangev(LL,xx)

%Subroutine for the evaluation of any polynomial represented by the vector LL(i,:)
%on the positions represented by the vector xx. 
%E.g. LL: the coefficients of the Lagrance polynomials
%     xx: the domain of the reference element [-1,1]


sL=size(LL);
lx=length(xx);
VP=zeros(sL(1),lx);
for k=1:sL                 
    p=LL(k,:);
    VP(k,:)=polyval(p,xx); 
end
