function[xq]=globalGLn(ksi,punti,n_el)


%Transformation ksi--->x;
%I.e., for an element k with x in [x_{k-1},x_k] the coordinates of the GL nodes are given by
% x=a_k*1+ b_k*ksi
% where a_k=(x_{k}+x_{k-1})/2 and b_k=(x_{k}-x_{k-1})/2
% Calculation of the affine transformation matrix F(k,:)=[a(k) b(k)]
ldof=length(ksi);
for j=1:n_el
a(j)=(punti(j+1)+punti(j))/2;
b(j)=(punti(j+1)-punti(j))/2;
F(j,:)=[b(j) a(j)];                       %Representation w.r.t. the format Matlab uses for polynomials, i.e. [x^n ... x^0]   
x(j,:)=F(j,:)*[ksi;ones(1,length(ksi))];
x(j,:)=polyval(F(j,:),ksi)     ;           %Alternate Calculation
if j==1
    xq(1:ldof,1)=x(j,:)';
else
    xq=[xq;x(j,2:end)'];
end
end
% xq=x;