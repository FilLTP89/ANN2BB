function [LL, dLL]=lagr_dlagr(ksi,k,pg1,N)

%Calculation of the coefficients of the Lagrance polynomials in the interval [-1 1]
LL=Lagrange(ksi); 

%Evaluation of the derivative of the Lagrance polynomials
for jj=1:length(LL(:,1))
    dLL_j=polyder(LL(jj,:));
    dLL(jj,:)=[dLL_j];
end

%========================
%        Figure 1
%========================
%Plot of the shape functions (Lagrance polynomials)
if pg1=='y'
xx=[-1:0.01:1];
VP=Lagrangev(LL,xx);
a=ones(1,k+2);
    figure(1)
    hold on;
    plot (ksi,a, 'o','MarkerEdgeColor','k','MarkerFaceColor','k');
    b=zeros(1,k+2);
    plot (ksi,b, 'o','MarkerEdgeColor','k','MarkerFaceColor','k') ;
    hold on;
    for ii=1:length(VP(:,1))
        plot(xx,VP(ii,:),'r');%xlim([-1,1])
        hold on;
    end
    xlabel('{\xi}')
end
%========================
