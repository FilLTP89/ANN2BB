function [strain] = make_strain_tensor(disp, node_lst, dphi, Ja,  ndof)

[nnod_el, nel] = size(node_lst);
strain = zeros(ndof,1);

for i = 1 : nel
    for j = 1 : nnod_el
    %coumpute sum_j dphi_j(xq)*uj for the i-th element 
    tmp = sum(dphi(:,j).*disp(node_lst(:,i))) * 2 / Ja(j,i);
    %sum all the contribution
    strain(node_lst(j,i)) = strain(node_lst(j,i)) + tmp;
    end
end