%********************************************************************************
% ONE-DIMENSIONAL SIMULATION OF WAVE PROPAGATION IN  ELASTIC SOIL               *
%                       BY THE SPECTRAL ELEMENT METHOD                          *                                             
%********************************************************************************

%   Definition of variables:                                                
%                                                                       
%   n_el                Number of Elemets
%   N                   Grade of the Interpolation Polynomial
%   nodelem             Number of Nodes of each Element 
%   ngl                 Local Degrees of Freedom
%   ndof                Global Degrees of Freedom
%   k                   Number of Internal Gauss-Lobatto Nodes in each Element
%   rho                 Density [kg/m^3]
%   beta_vel            Shear-wave Velocity [m/s]
%   G                   Shear Modulus [kg/(s^2 m)]
%   tend                Total Simulation Time 
%   amp, fmax, tzero    Parameters for the Formation of the Ricker Wavelet
%   Depth               Dimension of the Spatial Domain [m]
%   deltax              Spatial Discretization Interval
%   grid.points         Spatial Grid Nodes
%   ksi, weights        Nodes and Weights with respect to (w.r.t.) the Gauss-Lobatto Quadrature Formula
%   LL, dLL             Matrices of the Coefficients of the Lagrance Polynomials and
%                       of their Derivatives respectively, in the Reference Interval [-1,1]
%   phiq, dphiq         Basis Functions and their Derivatives on the the Quadrature Nodes, respectively
%   lista_nodi          Matrix of the Rearranged Index of the Quadrature Nodes
%   Ja                  Jacobian Determinant
%   ke(i)               Stiffness Matrix for the Element i
%   me(i)               Mass Matrix for the Element i
%   k                   Global Stiffness Matrix
%   m                   Global Mass Matrix
%   xq                  Vector of the Coordinates of the Gauss-Lobatto Nodes in the Global Reference System
%   deltat              Time Discretization Interval
%   cycles              Number of Cycles in Time
%   beta, gamma         Parameters for the Newmark Time-integration Scheme
%   uimp                Base Displacement (x=0)   
%   superf              Surface Displacement
%**************************************************************************************
clear all
close all
clc


addpath ./mapping.interpolation
addpath ./damping
addpath ./stiffness.mass


tic
%***************************************************************************************
%
%INPUT DATA
%***************************************************************************************
%Grade of the Interpolation Polynomial
N=4;

%Physical Parameters of the Soil Layer
n_layer=2;                            %Number of different soil layers
rho=[2500 2000];                           %Mass density array, rho(j)-->jth layer from base
beta_vel=[500 100];                       %Shear-wave velocity array
G=(beta_vel).^2.*rho;                 %Shear-modulus array

%Total time of the Simulation
tend=20;

%Ricker wavelet characteristics
amp=0.05;
tzero=2;
fmax=3;

%Characteristics of the Spatial Grid 
H_layer=[3000 60];

%Input variables for the introduction of damping
dampingtype=1;      %Type of Damping (Possible Values: none (0), Rayleigh (1), Caughey (2), Kosloff & Kosloff (3))
f=[1 5];             %f=[fi fj]: Control Frequencies
cdr=0.0005;            %Desired Damping Ratio in the range [fi,fj]
nf=4;                %Number of fixed-damping eigenfrequencies (applies in the case of Caughey Damping)


% %Checking Times of the Propagation
t_check_dt=[2 4 6 8];
%t_check_dt=[1];

%Variable for plotting(y)/not plotting(n) graphs;
%pg holds for PlotGraph
pg1='n';  %Shape Functions in the domain of the reference element [-1 1]
pg2='n';  %Wave snapshot at time t_check_dt
pg3='n';  %Animation of the propagation of the wave in time

control_point=1500; % Position of a point at which the displacement will be plotted and exported as an ASCII file
%**************************************************************************************
%Calculation of the Spatial Discretization Interval and of the number of elements
%**************************************************************************************
deltax=(beta_vel/fmax);  %One wavelength per spectral element 
dx=H_layer;

%Implementation of the criterion dx<deltax for each layer
for p=1:n_layer
    if dx(p)>deltax(p);
        temp=ceil(dx(p)/deltax(p));
        dx(p)=dx(p)/temp;
        nel_layer(p,1)=temp;
    else
        nel_layer(p,1)=1;
    end
end
clear temp
n_el=sum(nel_layer);

for p=1:n_layer
    if p==1
        h_el(1,1:nel_layer(p))=dx(p);
        G_el(1,1:nel_layer(p))=G(p);
        rho_el(1,1:nel_layer(p))=rho(p);
    else
        h_el(1,nel_layer(p-1)+1:nel_layer(p-1)+nel_layer(p))=dx(p);
        G_el(1,nel_layer(p-1)+1:nel_layer(p-1)+nel_layer(p))=G(p);
        rho_el(1,nel_layer(p-1)+1:nel_layer(p-1)+nel_layer(p))=rho(p);
    end
end
grid.points=[0,cumsum(h_el)];


nodelem=N+1;     %Number of element nodes
ngl=N+1;         %Local Degrees of Freedom  
ndof=N*n_el+1;   %Global Degrees of Freedom

%**************************************************************************************
%Calculation of the nodes and the weights w.r.t the Gauss-Lobatto quadrature
%**************************************************************************************
k=N-1;                              %Number of internal Gauss-Lobatto nodes per element
[ksi weights]=gauss_lobatto(N,k);       %GL nodes and respective weights on the reference subdomain
[xq]=globalGLn(ksi,grid.points,n_el);   %GL nodes in the global coordinate system

%Evaluation of the Lagrance Polynomials and their Derivatives in the interval [-1 1]
[LL, dLL]=lagr_dlagr(ksi,k,pg1,N);

%Values of the Basis functions and their derivatives on the Gauss-Lobatto nodes 
phiq =Lagrangev(LL,ksi); % ordered by row
dphiq=Lagrangev(dLL,ksi);

%List of nodes (i^{th} row: i^{th} local node;j^{th} column: j^{th} element)
for j=1:n_el;
for i=1:nodelem;
    nodes_list(i,j)=(j-1)*N+i;
end
end

%Evaluation of the Jacobian determinant at the GLL nodes
%j^th column: j^th element
%i^th row:    i^th local GLL node
for j=1:n_el
    x(:,j)=xq(nodes_list(:,j));
    Ja(:,j)=dphiq'*x(:,j);
end
toc

tic
display('Calculation of System''s Matrices')
%***********************************************************************************************************
%Calculation of the stiffness, mass and damping matrix
%***********************************************************************************************************
%Mass & Stiffness Matrix
[m, k] = mass_stiff(n_el,rho_el,G_el,...
                    phiq,dphiq,...
                    ngl,weights,ndof,...
                    nodelem,...
                    nodes_list,...
                    Ja);
m=sparse(m);
k=sparse(k);

%Damping Matrix
[c k] = damping(dampingtype,f,cdr,nf,k,m);
toc

tic
display('Time Integration')
%Courant-Levy-Frederichs Stability Condition for the time step
x_tr=xq(2:1:length(x));
diff=x_tr-xq(1:length(x)-1);
mindeltax=min(diff);
maxdeltat=0.2*(mindeltax/max(beta_vel));
deltat=maxdeltat;
t=0:deltat:tend;
t=t';

% %Imposed Base (node 1) Displacement (Ricker wavelet)
uimp=ricker(0,t,beta_vel(1),amp,fmax,tzero);                   
cycles=length(t);

%Imposed base displacement given as a vector
%********The following lines are to be un-commented if the input displacement 
%********is given as a vector
% u_history=load('ricker.inp');
% tm=u_history(:,1);
% uimpm=u_history(:,2);
% dt=tm(2)-tm(1);
% % dt=0.001
% if dt>deltat
%     uimp=interp1(tm,uimpm,t);
%     timestep=deltat;
% else
%     uimp=uimpm;
%     t=tm;
%     timestep=dt;
% end
% cycles=length(t);

% Initial Conditions for Displacement, Velocity, Acceleration
[aimp,vimp]=num_dif(uimp,cycles,deltat);

 [GMTS]=beta_method(uimp,vimp,aimp,...
                   cycles,...
                   deltat,...
                   m,k,c,...
                   N,...
                   xq,...
                   n_el,rho_el,G_el,...
                   phiq,dphiq,...
                   ngl,weights,ndof,...
                   nodelem,...
                   nodes_list,...
                   Ja,...
                   dampingtype,f,cdr,nf);

%Specific outputs and plots
%Displacement at x=control_point 
cpi=find(xq==control_point);   %Find the index of the node at the position x=control_point
control_disp = GMTS.dis(cpi,:);         
control_vel  = GMTS.vel(cpi,:);
control_acc  = GMTS.acc(cpi,:);
dhist=[t control_disp'];
vhist=[t control_vel'];
ahist=[t control_acc'];
save ./d3.out -ascii -tabs dhist
save ./v3.out -ascii -tabs vhist
save ./a3.out -ascii -tabs ahist
disp.history=[uimp' ;GMTS.dis];

plotting

% figure(10);
% subplot(211); plot(t,GMTS.dis(1,:));
% subplot(212); plot(t,GMTS.dis(size(GMTS.dis,1),:));

figure(11);
for j = 1:cycles 
 %plot([-5 5],[H_layer(1) H_layer(1)],'b-');
 %plot([-5 5],[H_layer(1) H_layer(1)]+H_layer(2),'b-');
 subplot(2,3,[1 4]);plot([uimp(j); GMTS.dis(:,j)],xq,'k-');
 xlim([-amp amp].*10);
 
 % Displacement - time
 subplot(2,3,2);plot(t(1:j),GMTS.dis(ndof-1,1:j),'k-');
 xlim([0 tend]); ylim([-amp amp].*10);
 
 subplot(2,3,5);plot(t(1:j),uimp(1:j),'k-');
 xlim([0 tend]); ylim([-amp amp].*10);
 
 % Stress - Strain
 figh=figure(11);
 axh=subplot(2,3,3,'Parent',figh);

 plot(axh,GMTS.eps_xy(ndof-1,1:j),...
         GMTS.sig_xy(ndof-1,1:j),...
         'k-');
 hold(axh,'on');
 plot(axh,GMTS.eps_xy(ndof-1,j),...
          GMTS.sig_xy(ndof-1,j),'ro');
 hold(axh,'off');

      
 
%  subplot(2,3,3);plot(GMTS.eps_xy(ndof-1,1:j),...
%                      GMTS.sig_xy(ndof-1,1:j),...
%                      'k-');
                 
 xlim([min(min(GMTS.eps_xy)) max(max(GMTS.eps_xy))]);
 ylim([min(min(GMTS.sig_xy)) max(max(GMTS.sig_xy))]);
 
 % GG0 - t
 subplot(2,3,6);plot(t(1:j),...
                     GMTS.sig_xy(ndof-1,1:j)./GMTS.eps_xy(ndof-1,1:j)./G(2),...
                     'k-');
xlim([0 tend]); ylim([0 2]);


 F(j) = getframe;
end
% Play the movie ten times
%movie(F,10)



toc
