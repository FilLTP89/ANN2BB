%Comparison between the response obtained at distance r from the source
%for different types of damping, dependent on the parameters chi, Q for a
%medium with shear wave velocity Vs

addpath ./../damping
addpath ./../

clear
clc
close all

%Position of the control point
r=1500;  

%Damping characteristics for the evaluation of 
%the exact internal dissipation
chi=0.7854;
Vs=500;
Q=10;

%Input variables for the evaluation of the ricker wave
amp=1;
tzero=0.5;
fmax=5;

%Reading of the numerical solution 
abc=load('abc1500.out');          %Kosloff & Kosloff damping
rd=load('rd1500.out');            %Rayleigh Damping
cad=load('cad1500.out');          %Caughey Damping

t=abc(:,1);                       %Overall time of sampling

%Analytical undamped solution
nd=ricker(r,t,Vs,amp,fmax,tzero);
nd=[t nd];

%Truncation of the time-domain response to the 
%non-zero values
index=find(abs(nd(:,2))>5e-6);
nd2=nd(index,2);
nd1=nd(index,1);

abc2=abc(index,2);
abc1=abc(index,1);

rd2=rd(index,2);
rd1=rd(index,1);

cad2=cad(index,2);
cad1=cad(index,1);

%Export of the truncated solution
save ./response_arrays/t5wl.out -ascii nd1
save ./response_arrays/nd5wl.out -ascii nd2
save ./response_arrays/abc5wl.out -ascii abc2
save ./response_arrays/rd5wl.out -ascii rd2
save ./response_arrays/cad5wl.out -ascii cad2

%Plot of the truncated solution
plot(nd1,nd2,abc1,abc2,rd1,rd2,cad1,cad2);...
    legend('Un-damped', 'Kosloff & Kosloff', 'Rayleigh', 'Caughey');xlabel('Time (sec)');...
    title('Time-domain Response at 5\lambda');
print -f1 -dtiff -r300 ./time.domain.response/disp_5wl
print -f1 -depsc -r300 ./time.domain.response/disp_5wl


%Evaluation of the Fourier Spectra
[Pnd,f1]=fourier(nd(:,2),t);
[Pabc,f2]=fourier(abc(:,2),t);
[Prd,f3]=fourier(rd(:,2),t);
[Pcd,f4]=fourier(cad(:,2),t);

%Evaluation of the Fouries Spectral ratio
%with reference to the spectrum of the undamped 
%solution
u1=Pabc./Pnd;
u2=Prd./Pnd;
u3=Pcd./Pnd;

%Analytical expression for the internal dissipation
%as function of the position of the control point (r)
%and the attenuation parameter (chi)/or the quality factor
%(Q)
exact1=exp(-r*chi/Vs)*ones(length(f1),1);
exact=exp(f1).^(-r*pi/(Q*Vs));

%Production of plots
figure;
plot(f1,u1,f1,u2,f1,u3,f1,exact1,'bx',...
    f1,exact,'rx');xlabel('frequency');...
    ylabel('$$\frac{\mid\;\mathcal{F}(x^D)\;\mid}{|\;\mathcal{F}(x^{UD})\;|}$$','Interpreter','latex');legend('Kosloff & Kosloff'...
    ,'Rayleigh','Caughey','Exact (\chi: constant)','Exact (Q: constant)');xlim([0.9 5.1]);...
    title('Internal Dissipation at 5\lambda');
print -f2 -dtiff -r300 ./dissipation/spectral_ratio_5wl
print -f2 -depsc -r300 ./dissipation/spectral_ratio_5wl

figure;plot(f1,Pnd,f1,Pabc,f1,Prd,f1,Pcd);...
    legend('Un-damped', 'Kosloff & Kosloff', 'Rayleigh', 'Caughey');xlabel('Frequency');...
    xlim([0.1 6]);title('Frequency-domain Response at 5\lambda')
print -f3 -dtiff -r300 ./frequency.domain.response/fr_response_5wl
print -f3 -depsc -r300 ./frequency.domain.response/fr_response_5wl
