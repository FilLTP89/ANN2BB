function[loc_mass_matr]=loc_mass_n(rho,phiq_n,ngl,weights,Ja) %csi sar� da cambiare con x

%Calculation of the local mass matrix
for i=1:ngl
    for j=1:ngl
         loc_mass_matr(i,j)=sum(Ja'.*weights.*(phiq_n(j,:).*phiq_n(i,:)))*rho;
    end
end