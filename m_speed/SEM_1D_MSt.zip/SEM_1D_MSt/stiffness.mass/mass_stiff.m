function [m, k, c, Ja]=mass_stiff(n_el,rho,G,...
                                  phiq,dphiq,...
                                  ngl,weights,ndof,...
                                  nodelem,...
                                  nodes_list,...
                                  Ja)

%Calculation of the global mass, damping and stiffness matrices

%  Local Matrices
for ii=1:n_el
    [loc_mass_matr]=loc_mass(rho(ii),phiq,ngl,weights,Ja(:,ii));
    me(:,:,ii)=loc_mass_matr;
    [loc_stiff_matr]=loc_stiff(G(ii),dphiq,ngl,weights,Ja(:,ii));
    ke(:,:,ii)=loc_stiff_matr;
end   


%Calculation of the global mass and stiffness matrices
k=zeros(ndof,ndof);
m=zeros(ndof,ndof);
for ie=1:n_el
    for iloc=1:nodelem
        i=nodes_list(iloc,ie);
        for jloc=1:nodelem
            j=nodes_list(jloc,ie);
            k(i,j)=k(i,j)+ke(iloc,jloc,ie);
            m(i,j)=m(i,j)+me(iloc,jloc,ie);
        end
    end
end


