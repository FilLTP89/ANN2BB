function[loc_stiff_matr]=loc_stiff_n(G,dphiq_n,ngl,weights,Ja) 

%Calculation of the local stiffness matrix
for i=1:ngl
    for j=1:ngl
        loc_stiff_matr(i,j)=sum(weights./Ja'.*(dphiq_n(j,:).*dphiq_n(i,:)))*G;
    end
end


