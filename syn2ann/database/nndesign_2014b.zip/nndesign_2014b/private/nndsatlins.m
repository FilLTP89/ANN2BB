function a = nndsatlins(n)

% Copyright 1995-2015 Martin T. Hagan and Howard B. Demuth

a = max(-1,min(1,n));
