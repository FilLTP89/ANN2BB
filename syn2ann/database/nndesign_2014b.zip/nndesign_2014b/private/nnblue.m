function c = nnblue
%NNRED Neural Network Design utility function.

% $Revision: 1.6 $
% Copyright 1995-2015 Martin T. Hagan and Howard B. Demuth
% First Version, 8-31-95.

%==================================================================

c = [0 0 1];  %[0.8 0.8 0.8];
