function a = nndhardlims(n)
% Copyright 1995-2015 Martin T. Hagan and Howard B. Demuth

a = 2*(n >= 0)-1;
