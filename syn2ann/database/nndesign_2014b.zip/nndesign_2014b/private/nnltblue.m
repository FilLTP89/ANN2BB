function c=nnltblue
%NNLTBLUE Neural Network Design utility function.

% Copyright 1995-2015 Martin T. Hagan and Howard B. Demuth

c = [0.5 0.5 1];
