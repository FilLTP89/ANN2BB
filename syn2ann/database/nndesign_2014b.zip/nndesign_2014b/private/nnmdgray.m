function c = nnmdgray
%NNMDGRAY Neural Network Design utility function.

% Copyright 1995-2015 Martin T. Hagan and Howard B. Demuth
% First Version, 8-31-95.

%==================================================================

c = [0.55 0.55 0.55];
