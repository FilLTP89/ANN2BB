function c = nnwhite
%NNWHITE White used by Neural Network Toolbox GUI
  
%  NNWHITE returns rgb triple for white.

% Mark Beale 6-4-94
% Copyright 1995-2015 Martin T. Hagan and Howard B. Demuth

c = [1 1 1];
