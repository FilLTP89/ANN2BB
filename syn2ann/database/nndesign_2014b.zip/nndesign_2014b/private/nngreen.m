function c = nngreen
%NNGREEN Green used by Neural Network Toolbox GUI.
  
%  NNGREEN returns rgb triple for green.

% Mark Beale 6-4-94
% Copyright 1995-2015 Martin T. Hagan and Howard B. Demuth

c = [0 0.7 0];
