function a = nndhardlim(n)

% Copyright 1995-2015 Martin T. Hagan and Howard B. Demuth

a = double(n >= 0);
