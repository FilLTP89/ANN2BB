var index =
[
    [ "License", "index.html#sec1000", null ],
    [ "References", "index.html#sec2000", null ],
    [ "Installation", "page1.html", [
      [ "Installation on Unix/Linux OS", "page1.html#sec1", null ],
      [ "Installation on Windows OS", "page1.html#sec2", null ]
    ] ],
    [ "User guide", "page2.html", [
      [ "A SPEEDy user's guide", "page2.html#sec21", [
        [ "SPEED.input", "page2.html#sub211", null ],
        [ "Mesh File", "page2.html#sub212", null ],
        [ "Material File", "page2.html#sub213", null ],
        [ "Monitors File", "page2.html#sub214", null ]
      ] ]
    ] ],
    [ "Tutorials", "page3.html", [
      [ "Plane wave analysis", "page3.html#sec31", [
        [ "Test SEm", "page3.html#subsec311", null ],
        [ "Test SEm non-linear material", "page3.html#subsec312", null ],
        [ "Test SEm not-honoring", "page3.html#subsec313", null ],
        [ "Test DG", "page3.html#subsec314", null ],
        [ "Post-processing and visualization", "page3.html#subsec315", null ]
      ] ],
      [ "LOH1 test case", "page3.html#sec32", [
        [ "Execution", "page3.html#subsec321", null ],
        [ "Post-processing and visualization", "page3.html#subsec322", null ]
      ] ]
    ] ],
    [ "Input files generation", "page4.html", [
      [ "Mesh file", "page4.html#sec61", [
        [ "How to generate the geometry of the problem", "page4.html#subsec611", null ],
        [ "FileName.e to FileName.txt", "page4.html#subsec612", null ],
        [ "FileName.txt to FileName.mesh", "page4.html#subsec613", null ],
        [ "ALL(XYZ).txt to ALL(XYZ).out", "page4.html#subsec614", null ]
      ] ],
      [ "LS.input file", "page4.html#sec62", [
        [ "LS.input generation", "page4.html#subsec621", null ],
        [ "From LS.e to LS.txt", "page4.html#subsec622", null ],
        [ "From  LS.txt to LS.mesh", "page4.html#subsec623", null ]
      ] ]
    ] ],
    [ "Earthquake scenario simulations", "page5.html", null ],
    [ "Web-Repository", "page6.html", null ]
];